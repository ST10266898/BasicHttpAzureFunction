using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace MyHttpFunction
{
    public static class SayHello
    {
        [FunctionName("SayHello")]
        public static IActionResult Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("Azure Function 'SayHello' triggered.");

            string name = req.Query["name"];

            if (string.IsNullOrWhiteSpace(name))
            {
                return new BadRequestObjectResult("Please provide a name in the query string (?name=YourName).");
            }

            string responseMessage = $"Hello, \"{name}\"! Your Azure Function executed successfully.";
            return new OkObjectResult(responseMessage);
        }
    }
}
